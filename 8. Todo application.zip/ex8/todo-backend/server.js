const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(bodyParser.json());

const todosFilePath = path.join(__dirname, 'todos.json');

// Function to get todos
const getTodos = () => {
  if (!fs.existsSync(todosFilePath)) {
    fs.writeFileSync(todosFilePath, JSON.stringify([]));
  }
  const data = fs.readFileSync(todosFilePath);
  return JSON.parse(data);
};

// Function to save todos
const saveTodos = (todos) => {
  fs.writeFileSync(todosFilePath, JSON.stringify(todos, null, 2));
};

// Endpoint to get todos
app.get('/todos', (req, res) => {
  const todos = getTodos();
  res.json(todos);
});

// Endpoint to add a new todo
app.post('/todos', (req, res) => {
  const newTodo = req.body;
  const todos = getTodos();
  todos.push(newTodo);
  saveTodos(todos);
  res.status(201).json(newTodo);
});

// Endpoint to delete a todo
app.delete('/todos/:id', (req, res) => {
  const { id } = req.params;
  let todos = getTodos();
  todos = todos.filter(todo => todo.id !== id);
  saveTodos(todos);
  res.status(204).send();
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
