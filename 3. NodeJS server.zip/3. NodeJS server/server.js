const http = require('http');           // To create the web server
const fs = require('fs');               // To read files
const path = require('path');           // To work with file paths

const server = http.createServer((req, res) => {
  let filePath = '.' + req.url;         // Get requested file path

  // If root is requested, load index.html
  if (filePath === './') {
    filePath = './index.html';
  }

  // Get the file extension (like .html or .css)
  const extname = path.extname(filePath);

  // Define content types for different file types
  const mimeTypes = {
    '.html': 'text/html',
    '.css': 'text/css'
  };

  // Set the correct content type
  const contentType = mimeTypes[extname] || 'application/octet-stream';

  // Read the file from disk
  fs.readFile(filePath, (err, content) => {
    if (err) {
      // If file not found, send 404
      if (err.code === 'ENOENT') {
        res.writeHead(404, { 'Content-Type': 'text/html' });
        res.end('<h1>404 Not Found</h1>');
      } else {
        // For other errors, send 500
        res.writeHead(500);
        res.end(`Server Error: ${err.code}`);
      }
    } else {
      // Success - send file content
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(content);
    }
  });
});

// Start the server on port 3000
const PORT = 3000;
server.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}`);
});
